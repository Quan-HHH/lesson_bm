## h5案例打击乐

- 程序员文档编写格式 markdown， 具有广泛的支持

- html5 具有强大表现力

用html5 + css3 模拟一个pc 打击键盘

vscode内置支持emmit

